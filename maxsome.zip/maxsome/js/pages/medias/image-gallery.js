$(function () {
    $('#aniimated-thumbnials-all').lightGallery({
        thumbnail: true,
        selector: 'a'
    });
    $('#aniimated-thumbnials-Birthday').lightGallery({
        thumbnail: true,
        selector: 'a'
    });
    $('#aniimated-thumbnials-Events').lightGallery({
        thumbnail: true,
        selector: 'a'
    });
});