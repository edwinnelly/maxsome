<?php
$password = '12345';
$hashedPassword = password_hash($password, PASSWORD_BCRYPT);
 "Hashed Password: " . $hashedPassword;


 echo $id = uniqid()
?>